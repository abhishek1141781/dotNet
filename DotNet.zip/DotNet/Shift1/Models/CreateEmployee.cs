﻿namespace Shift1.Models
{
    public class CreateEmployee
    {
        public string Name { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
    }
}
