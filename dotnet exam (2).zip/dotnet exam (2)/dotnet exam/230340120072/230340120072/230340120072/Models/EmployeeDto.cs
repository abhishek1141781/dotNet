﻿namespace b1.Models
{
    public class EmployeeDto
    {
        public string Name { get; set; }
        public string City { get; set; }
        public string Address { get; set; }
    }
}
