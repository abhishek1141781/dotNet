﻿using b1.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace b1.Controllers
{
    public class EmployeeController : Controller
    {

        //-------------------------------------------------------------INDEX------------------------------------------------------------------
        // GET: EmployeeController
        public ActionResult Index()
        {
            return View(DbOperations.GetAllEmployees());
        }

        //-------------------------------------------------------------EDIT------------------------------------------------------------------
        // GET: EmployeeController/Edit/5
        public ActionResult Edit(int id)
        {
            return View(DbOperations.GetEmployee(id));
        }

        // POST: EmployeeController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Employee emp)
        {
            try
            {
                DbOperations.EditEmployee(emp);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        //------------------------------------------------ADD NEW-------------------------------------------------------
        // GET: EmployeeController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: EmployeeController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Employee emp)
        {
            try
            {
                Employee e = new Employee { Id = emp.Id, Name = emp.Name, City = emp.City, Address = emp.Address };
                DbOperations.AddEmployee(e);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        //------------------------------------------------DELETE-------------------------------------------------------
        // GET: EmployeeController/Delete/5
        public ActionResult Delete(int id)
        {
            return View(DbOperations.GetEmployee(id));
        }

        // POST: EmployeeController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, Employee emp)
        {
            try
            {
                DbOperations.DeleteEmployee(id);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
