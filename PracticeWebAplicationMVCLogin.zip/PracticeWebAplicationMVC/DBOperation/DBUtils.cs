﻿namespace PracticeWebAplicationMVC.DBOperation
{
    public class DBUtils
    {
       // public static  getInstance() { }
    }
}
